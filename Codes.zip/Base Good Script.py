def power(base, exp, mod):
    return pow(base, exp, mod)  # Python built-in handles big ints natively

def miller_test(n, a, d, r):
    x = power(a, d, n)
    if x == 1 or x == n - 1:
        return False  # not a witness
    for _ in range(r - 1):
        x = x * x % n
        if x == n - 1:
            return False  # not a witness
    return True  # a is a witness => n is COMPOSITE

def is_prime(n):
    if n < 2: return False
    if n in (2, 3, 5, 7): return True
    if n % 2 == 0 or n % 3 == 0: return False

    # Write n-1 as 2^r * d
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1

    # Choose bases based on size of n
    if n < 2047:
        bases = [2]
    elif n < 1_373_653:
        bases = [2, 3]
    elif n < 9_080_191:
        bases = [31, 73]
    elif n < 25_326_001:
        bases = [2, 3, 5]
    elif n < 3_215_031_751:
        bases = [2, 3, 5, 7]
    elif n < 4_759_123_141:
        bases = [2, 7, 61]
    elif n < 1_122_004_669_633:
        bases = [2, 13, 23, 1_662_803]
    elif n < 2_152_302_898_747:
        bases = [2, 3, 5, 7, 11]
    elif n < 3_474_749_660_383:
        bases = [2, 3, 5, 7, 11, 13]
    elif n < 341_550_071_728_321:
        bases = [2, 3, 5, 7, 11, 13, 17]
    elif n < 3_825_123_056_546_413_051:
        bases = [2, 3, 5, 7, 11, 13, 17, 19, 23]
    else:
        bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]  # up to 3.3 * 10^24

    for a in bases:
        if a >= n:
            continue
        if miller_test(n, a, d, r):
            return False  # composite

    return True  # definitely prime


if __name__ == "__main__":
    print("=== Deterministic Miller-Rabin Demo ===\n")

    test_cases = [
        (561,                       "Carmichael number (fools Fermat)"),
        (1105,                      "Carmichael number"),
        (999_999_937,               "Large prime"),
        (1_000_000_007,             "Large prime"),
        (1_000_000_009,             "Large prime"),
        (998_244_353,               "NTT prime"),
        (2_147_483_647,             "Mersenne prime (2^31 - 1)"),
        (4_294_967_291,             "Large prime near 2^32"),
        (100,                       "Composite (10^2)"),
        (3_215_031_751,             "Composite, needs 4 bases to catch"),
    ]

    for n, label in test_cases:
        result = "PRIME" if is_prime(n) else "COMPOSITE"
        print(f"{n}  [{label}]")
        print(f"  => {result}\n")

    print("=== Counting primes up to 10,000,000 ===")
    count = sum(1 for i in range(2, 10_000_001) if is_prime(i))
    print(f"Count: {count}  (correct answer: 664579)")