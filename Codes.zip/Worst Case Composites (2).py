import os
import numpy as np
import matplotlib
matplotlib.use("Agg")  # save to files even in headless environments
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

# ---------------------------
# CORE FUNCTIONS
# ---------------------------

def miller_rabin_round(n, a):
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1

    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True

    for _ in range(r - 1):
        x = (x * x) % n
        if x == n - 1:
            return True

    return False


def exact_liar_fraction(n):
    total = n - 3
    liars = sum(1 for a in range(2, n - 1) if miller_rabin_round(n, a))
    return liars / total


def sieve(limit):
    is_prime = bytearray([1]) * (limit + 1)
    is_prime[0] = is_prime[1] = 0
    for i in range(2, int(limit ** 0.5) + 1):
        if is_prime[i]:
            is_prime[i * i : limit + 1 : i] = bytearray(
                len(is_prime[i * i : limit + 1 : i])
            )
    return is_prime


# ---------------------------
# DATA
# ---------------------------

LIMIT = 300000
OUTDIR = "F:\SEM6\CS648\Project"

is_prime = sieve(LIMIT)

carmichaels = {
    561, 1105, 1729, 2465, 2821, 6601, 8911, 10585,
    15841, 29341, 41041, 46657, 52633, 62745, 63973, 75361
}

ns = []
fracs = []

for n in range(9, LIMIT + 1, 2):
    if is_prime[n]:
        continue
    print(n)
    ns.append(n)
    fracs.append(exact_liar_fraction(n))

ns = np.array(ns)
fracs = np.array(fracs)

# shared derived arrays so nothing is recomputed later
is_carm = np.array([n in carmichaels for n in ns])

# top 60 worst cases by liar fraction
idx = np.argsort(fracs)[-60:][::-1]
top_ns = ns[idx]
top_fracs = fracs[idx]
top_is_carm = np.array([n in carmichaels for n in top_ns])

# a smaller zoomed region for easier reading
mask = ns <= LIMIT/10
zoom_ns = ns[mask]
zoom_fracs = fracs[mask]
zoom_is_carm = np.array([n in carmichaels for n in zoom_ns])

# ---------------------------
# STYLE
# ---------------------------

plt.style.use("seaborn-v0_8-whitegrid")
plt.rcParams.update({
    "figure.figsize": (16, 5.8),
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "xtick.labelsize": 8,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
})

# ---------------------------
# FIGURE 1: scatter + histogram
# ---------------------------

fig1, axes = plt.subplots(1, 2, figsize=(15, 5.5))
fig1.suptitle(
    "Miller–Rabin exact liar fractions for odd composites up to 10000",
    fontsize=14,
    fontweight="bold",
    y=1.02
)

# Left: scatter plot
ax = axes[0]
ax.scatter(
    ns[~is_carm], fracs[~is_carm],
    s=14, alpha=0.65, label="Odd composites", linewidths=0
)
ax.scatter(
    ns[is_carm], fracs[is_carm],
    s=95, marker="D", color="crimson",
    edgecolors="black", linewidths=0.7,
    label="Carmichael numbers"
)
ax.axhline(0.25, color="darkorange", linestyle="--", linewidth=2, label="1/4 bound")

for n, f in zip(ns[is_carm], fracs[is_carm]):
    ax.annotate(
        str(n),
        (n, f),
        textcoords="offset points",
        xytext=(0, 7),
        ha="center",
        fontsize=8,
        color="crimson",
        fontweight="bold"
    )

ax.set_xlabel("Odd composite number n")
ax.set_ylabel("Exact liar fraction")
ax.set_title("Exact liar fraction vs composite n")
ax.set_ylim(-0.01, 0.32)
ax.grid(True, linestyle=":", alpha=0.6)
ax.legend(loc="upper right")

# Right: histogram
ax = axes[1]
bins = np.linspace(0, 0.30, 35)
counts, edges = np.histogram(fracs, bins=bins)
centers = 0.5 * (edges[:-1] + edges[1:])
colors = ["steelblue" if c < 0.25 else "tomato" for c in centers]

ax.bar(
    edges[:-1], counts, width=np.diff(edges), align="edge",
    color=colors, edgecolor="white", linewidth=0.6, alpha=0.9
)
ax.axvline(0.25, color="darkorange", linestyle="--", linewidth=2, label="1/4 bound")
ax.set_xlabel("Exact liar fraction")
ax.set_ylabel("Number of odd composites")
ax.set_title("Distribution of exact liar fractions")
ax.grid(True, axis="y", linestyle=":", alpha=0.6)
ax.legend(loc="upper right")

ax.text(
    0.98, 0.96,
    f"max = {fracs.max():.4f}\nmean = {fracs.mean():.4f}\nCarmichael count = {is_carm.sum()}",
    transform=ax.transAxes,
    ha="right",
    va="top",
    fontsize=9,
    bbox=dict(boxstyle="round,pad=0.4", facecolor="white", edgecolor="gray", alpha=0.9),
)

fig1.tight_layout()
fig1.savefig(os.path.join(OUTDIR, "miller_rabin_liar_fractions.png"), dpi=300, bbox_inches="tight")
fig1.savefig(os.path.join(OUTDIR, "miller_rabin_liar_fractions.pdf"), bbox_inches="tight")
plt.close(fig1)

# ---------------------------
# FIGURE 2: worst cases + zoomed view
# ---------------------------

fig2, axes = plt.subplots(1, 2, figsize=(16, 5.8))
fig2.suptitle(
    "Worst-case odd composites for Miller–Rabin (sorted by exact liar fraction)",
    fontsize=14,
    fontweight="bold",
    y=1.02
)

# Left: top 60 bar chart
ax = axes[0]
x = np.arange(len(top_ns))
bar_colors = ["crimson" if n in carmichaels else "steelblue" for n in top_ns]

ax.bar(
    x, top_fracs,
    color=bar_colors,
    edgecolor="black",
    linewidth=0.4,
    alpha=0.9
)

ax.axhline(0.25, color="darkorange", linestyle="--", linewidth=2, label="1/4 bound")
ax.set_xticks(x)
ax.set_xticklabels([str(n) for n in top_ns], rotation=60, ha="right")
ax.set_xlabel("Composite n (top 60 worst cases)")
ax.set_ylabel("Exact liar fraction")
ax.set_title("Top 60 composites by liar fraction")
ax.set_ylim(0, 0.31)
ax.grid(True, axis="y", linestyle=":", alpha=0.6)

for i, (n, f) in enumerate(zip(top_ns, top_fracs)):
    if n in carmichaels:
        ax.text(
            i, f + 0.006, str(n),
            ha="center", va="bottom",
            rotation=90,
            fontsize=8,
            color="crimson",
            fontweight="bold"
        )

legend_handles = [
    Line2D([0], [0], color="darkorange", lw=2, linestyle="--", label="1/4 bound"),
    Line2D([0], [0], marker="s", color="w", markerfacecolor="steelblue",
           markeredgecolor="black", markersize=10, label="Other composites"),
    Line2D([0], [0], marker="s", color="w", markerfacecolor="crimson",
           markeredgecolor="black", markersize=10, label="Carmichael numbers"),
]
ax.legend(handles=legend_handles, loc="upper right")

# Right: zoomed scatter
ax = axes[1]
ax.scatter(
    zoom_ns[~zoom_is_carm], zoom_fracs[~zoom_is_carm],
    s=30, alpha=0.75, color="steelblue", label="Other composites"
)
ax.scatter(
    zoom_ns[zoom_is_carm], zoom_fracs[zoom_is_carm],
    s=95, marker="D", color="crimson",
    edgecolors="black", linewidths=0.7,
    label="Carmichael numbers"
)
ax.axhline(0.25, color="darkorange", linestyle="--", linewidth=2, label="1/4 bound")

for n, f in zip(zoom_ns[zoom_is_carm], zoom_fracs[zoom_is_carm]):
    ax.annotate(
        str(n),
        (n, f),
        textcoords="offset points",
        xytext=(0, 8),
        ha="center",
        fontsize=8,
        color="crimson",
        fontweight="bold"
    )

ax.set_xlabel("Composite n")
ax.set_ylabel("Exact liar fraction")
ax.set_title("Zoomed view for n <=10000")
ax.set_ylim(-0.01, 0.32)
ax.grid(True, linestyle=":", alpha=0.6)
ax.legend(loc="upper right")

ax.text(
    0.98, 0.96,
    "Carmichael numbers are\nshown in red diamonds",
    transform=ax.transAxes,
    ha="right",
    va="top",
    fontsize=9,
    bbox=dict(boxstyle="round,pad=0.4", facecolor="white", edgecolor="gray", alpha=0.9),
)

fig2.tight_layout()
fig2.savefig(os.path.join(OUTDIR, "miller_rabin_worst_cases.png"), dpi=300, bbox_inches="tight")
fig2.savefig(os.path.join(OUTDIR, "miller_rabin_worst_cases.pdf"), bbox_inches="tight")
plt.close(fig2)

# ---------------------------
# OPTIONAL: save each panel separately too
# ---------------------------

# Top-60 bar chart alone
fig3, ax = plt.subplots(figsize=(14, 5.5))
ax.bar(
    np.arange(len(top_ns)), top_fracs,
    color=["crimson" if n in carmichaels else "steelblue" for n in top_ns],
    edgecolor="black", linewidth=0.4, alpha=0.9
)
ax.axhline(0.25, color="darkorange", linestyle="--", linewidth=2)
ax.set_xticks(np.arange(len(top_ns)))
ax.set_xticklabels([str(n) for n in top_ns], rotation=60, ha="right")
ax.set_xlabel("Composite n (top 60 worst cases)")
ax.set_ylabel("Exact liar fraction")
ax.set_title("Top 60 composites by liar fraction")
ax.set_ylim(0, 0.31)
ax.grid(True, axis="y", linestyle=":", alpha=0.6)
fig3.tight_layout()
fig3.savefig(os.path.join(OUTDIR, "miller_rabin_top60.png"), dpi=300, bbox_inches="tight")
plt.close(fig3)

# Zoomed scatter alone
fig4, ax = plt.subplots(figsize=(8, 5.8))
ax.scatter(
    zoom_ns[~zoom_is_carm], zoom_fracs[~zoom_is_carm],
    s=30, alpha=0.75, color="steelblue", label="Other composites"
)
ax.scatter(
    zoom_ns[zoom_is_carm], zoom_fracs[zoom_is_carm],
    s=95, marker="D", color="crimson",
    edgecolors="black", linewidths=0.7,
    label="Carmichael numbers"
)
ax.axhline(0.25, color="darkorange", linestyle="--", linewidth=2, label="1/4 bound")
for n, f in zip(zoom_ns[zoom_is_carm], zoom_fracs[zoom_is_carm]):
    ax.annotate(
        str(n),
        (n, f),
        textcoords="offset points",
        xytext=(0, 8),
        ha="center",
        fontsize=8,
        color="crimson",
        fontweight="bold"
    )
ax.set_xlabel("Composite n")
ax.set_ylabel("Exact liar fraction")
ax.set_title("Zoomed view for n ≤ 300")
ax.set_ylim(-0.01, 0.32)
ax.grid(True, linestyle=":", alpha=0.6)
ax.legend(loc="upper right")
fig4.tight_layout()
fig4.savefig(os.path.join(OUTDIR, "miller_rabin_zoomed.png"), dpi=300, bbox_inches="tight")
plt.close(fig4)

print("Saved files in:", OUTDIR)
print("miller_rabin_liar_fractions.png")
print("miller_rabin_liar_fractions.pdf")
print("miller_rabin_worst_cases.png")
print("miller_rabin_worst_cases.pdf")
print("miller_rabin_top60.png")
print("miller_rabin_zoomed.png")