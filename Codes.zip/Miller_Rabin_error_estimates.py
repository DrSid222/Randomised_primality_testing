import os
import random
import math
import pandas as pd

random.seed(42)


# -------------------------------------------------
# Helpers
# -------------------------------------------------
def is_prime(n: int) -> bool:
    """Deterministic primality check for building composite test sets."""
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return n in (2, 3)

    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True


def miller_rabin(n: int, k: int = 10) -> bool:
    """
    Miller-Rabin primality test.
    Returns True if n is probably prime, False if definitely composite.
    """
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False

    # write n-1 = 2^s * d
    s = 0
    d = n - 1
    while d % 2 == 0:
        d //= 2
        s += 1

    for _ in range(k):
        a = random.randint(2, n - 2)

        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue

        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False

    return True


def generate_composites(count: int = 100, low: int = 100, high: int = 300000):
    """
    Build a reasonably large set of composite numbers.
    Includes known Carmichael numbers first, then random odd composites.
    """
    carmichaels = [
        561, 1105, 1729, 2465, 2821, 6601, 8911,
        10585, 15841, 29341, 41041, 46657, 52633,
        62745, 63973, 75361, 101101, 115921, 126217
    ]

    composites = list(carmichaels)

    while len(composites) < count:
        candidate = random.randint(low, high)
        if candidate % 2 != 0 and not is_prime(candidate) and candidate not in composites:
            composites.append(candidate)

    return composites[:count]


# -------------------------------------------------
# Experiment
# -------------------------------------------------
def miller_rabin_error_table(
    num_numbers: int = 50,
    k_values=(1, 2, 3, 5, 10),
    trials_per_number: int = 2000000,
    output_csv: str = "miller_rabin_error_table.csv"
):
    """
    For many composite numbers, estimate Miller-Rabin error probability
    for each k and put it in a table.

    Error probability here means:
    P(test says 'probably prime' | input is composite)
    estimated empirically by repeated random trials.
    """
    composites = generate_composites(count=num_numbers)

    rows = []
    for n in composites:
        row = {
            "n": n,
            "carmichael_like": "YES" if n in {
                561, 1105, 1729, 2465, 2821, 6601, 8911,
                10585, 15841, 29341, 41041, 46657, 52633,
                62745, 63973, 75361, 101101, 115921, 126217
            } else "NO"
        }

        for k in k_values:
            failures = 0
            for _ in range(trials_per_number):
                if miller_rabin(n, k):
                    failures += 1
            row[f"error_k={k}"] = round(failures / trials_per_number, 10)

        rows.append(row)
        print(f"Finished n={n}")

    df = pd.DataFrame(rows)
    df = df.sort_values("n").reset_index(drop=True)

    # Save in current working directory
    csv_path = os.path.join(os.getcwd(), output_csv)
    df.to_csv(csv_path, index=False)

    print(f"\nSaved table to: {csv_path}\n")
    print(df.to_string(index=False))

    return df


# -------------------------------------------------
# Run it
# -------------------------------------------------
if __name__ == "__main__":
    df = miller_rabin_error_table(
        num_numbers=100,          # increase this for a bigger table
        k_values=(1, 2, 3, 5, 10, 15),
        trials_per_number=1000000,  # increase for smoother probabilities
        output_csv="miller_rabin_error_table.csv"
    )