import math
import time
import multiprocessing as mp
from functools import partial
import matplotlib.pyplot as plt
import numpy as np

# --- CONFIGURATION ---
LIMIT_N = 500000          # How far up the number line to check for composites
LIMIT_BASE = 50000          # How many bases (a=2 to 50) to rank
# ---------------------

def is_prime_deterministic(n):
    """Standard check to build our composite 'Hit List'"""
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0 or n % 3 == 0: return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0: return False
        i += 6
    return True

def miller_rabin_base_test(n, a):
    """The core logic: Returns True if n passes as 'Probably Prime' for base a"""
    s, d = 0, n - 1
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True
    return False

def audit_base_reliability(a, composite_list):
    """
    Worker function: Tests a single base against all known composites.
    Returns the count of how many composites this base 'caught'.
    """
    caught_count = 0
    for n in composite_list:
        if a < n:
            # If the test returns False, it means the base caught a composite!
            if not miller_rabin_base_test(n, a):
                caught_count += 1
    return (a, caught_count)

if __name__ == '__main__':
    num_cores = mp.cpu_count()
    print(f"--- Reliability Audit Initialized ---")
    print(f"Cores: {num_cores} | N-Limit: {LIMIT_N} | Base-Limit: {LIMIT_BASE}")

    # Step 1: Pre-calculate the 'Hit List' (All odd composites)
    print(f"Generating list of odd composites up to {LIMIT_N}...")
    start_setup = time.time()
    # We only care about odd composites because even ones are trivial
    composites_list = [n for n in range(3, LIMIT_N, 2) if not is_prime_deterministic(n)]
    print(f"Setup complete. Found {len(composites_list)} composites in {time.time()-start_setup:.2f}s.\n")

    # Step 2: Parallel Audit
    bases_to_rank = range(2, LIMIT_BASE + 1)
    worker_func = partial(audit_base_reliability, composite_list=composites_list)

    print(f"Ranking bases 2 through {LIMIT_BASE}...")
    start_audit = time.time()
    with mp.Pool(processes=num_cores) as pool:
        results = pool.map(worker_func, bases_to_rank)
    
    print(f"Audit finished in {time.time()-start_audit:.2f} seconds.")

    # We save a dictionary of {base: catch_count}
    reliability_data = {res[0]: res[1] for res in results}
    with open('base_reliability_results.pkl', 'wb') as f:
        pickle.dump(reliability_data, f)
    print(f"\n[SUCCESS] Reliability data saved to 'base_reliability_results.pkl'")
    # ----------------------------

    # Step 3: Sort and Prepare Data
    # Sort by catch count (descending)
    results.sort(key=lambda x: x[1], reverse=True)
    top_bases = [str(r[0]) for r in results]
    catch_counts = [r[1] for r in results]
    
    # Calculate percentage caught
    total_comp = len(composites_list)
    catch_percentages = [(c / total_comp) * 100 for c in catch_counts]

    # Step 4: Plotting
    plt.figure(figsize=(14, 7))
    bars = plt.bar(top_bases[:20], catch_percentages[:20], color='midnightblue') # Top 20
    
    plt.title(f"Witness Reliability: Top 20 Bases (Tested against odd composites till {LIMIT_N})", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel("Base (a)", fontsize=12)
    plt.ylabel("Percentage of Coprime Composites Caught (%)", fontsize=12)
    plt.ylim(99.4, 100.05) 
    
    # Label bars with exact percentages
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                 f'{height:.2f}%', ha='center', va='bottom', fontsize=9)

    plt.grid(axis='y', linestyle='--', alpha=0.6)
    plt.tight_layout()
    plt.show()