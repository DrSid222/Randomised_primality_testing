import os
import random
import math
import numpy as np
import matplotlib.pyplot as plt

random.seed(42)


# -----------------------------
# Basic primality helper
# -----------------------------
def is_prime(n: int) -> bool:
    """Deterministic primality check for moderate-sized integers."""
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return n in (2, 3)

    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True


# -----------------------------
# Miller-Rabin
# -----------------------------
def miller_rabin(n: int, k: int = 10) -> bool:
    """
    Miller-Rabin probable-prime test using k random bases.
    Returns True if n is probably prime, False if definitely composite.
    """
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False

    # Write n - 1 = 2^s * d with d odd
    s = 0
    d = n - 1
    while d % 2 == 0:
        d //= 2
        s += 1

    for _ in range(k):
        a = random.randint(2, n - 2)
        x = pow(a, d, n)

        if x == 1 or x == n - 1:
            continue

        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False

    return True


def miller_rabin_verbose(n: int, a: int) -> bool:
    """
    Miller-Rabin test for a fixed base a.
    Returns True if base a does NOT witness compositeness.
    """
    if n <= 1:
        return False
    if n in (2, 3):
        return True
    if n % 2 == 0:
        return False

    a %= n
    if a < 2:
        return True  # not a useful witness

    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True

    for _ in range(s - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return True

    return False


# -----------------------------
# Fermat test
# -----------------------------
def fermat_test(n: int, a: int) -> bool:
    """Simple Fermat test for a fixed base a."""
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return n == 2

    a %= n
    if a < 2:
        return True
    if math.gcd(a, n) != 1:
        return False

    return pow(a, n - 1, n) == 1


def is_fermat_prime(n: int, k: int = 1) -> bool:
    """Fermat primality test with k random bases."""
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False

    for _ in range(k):
        a = random.randint(2, n - 2)
        if math.gcd(a, n) != 1:
            return False
        if pow(a, n - 1, n) != 1:
            return False
    return True


# -----------------------------
# Plot save helper
# -----------------------------
def save_plot(filename: str) -> str:
    path = os.path.join(os.getcwd(), filename)
    plt.savefig(path, dpi=300, bbox_inches="tight")
    return path


# -----------------------------
# Experiment 1
# Carmichael numbers + liars
# -----------------------------
def run_comparison(limit: int = 2000):
    carmichael_numbers = [561, 1105, 1729, 2465, 2821, 6601, 8911]

    print(f"{'Number':<10} | {'Is Carmichael?':<15} | {'Fermat Result':<15} | {'Miller-Rabin Result'}")
    print("-" * 70)

    for n in range(3, limit, 2):
        if n in carmichael_numbers:
            f_liars = sum(1 for a in range(2, n) if math.gcd(a, n) == 1 and fermat_test(n, a))
            mr_liars = sum(1 for a in range(2, n) if math.gcd(a, n) == 1 and miller_rabin_verbose(n, a))

            print(f"{n:<10} | {'YES':<15} | {f_liars} liars | {mr_liars} liars")


run_comparison()


# -----------------------------
# Experiment 2
# Error probability vs k
# -----------------------------
tough_composites = [561, 1105, 1729, 2465, 2821, 6601, 8911]
k_values = range(1, 11)
trials = 200000

plt.figure(figsize=(10, 6))

for n in tough_composites:
    experimental_rates = []

    for k in k_values:
        failures = 0
        for _ in range(trials):
            if miller_rabin(n, k):
                failures += 1
        experimental_rates.append(failures / trials)

    plt.plot(list(k_values), experimental_rates, marker='o', label=f'Experimental (n={n})')

theoretical_rates = [(1 / 4) ** k for k in k_values]
plt.plot(list(k_values), theoretical_rates, 'r--', linewidth=2, label='Theoretical Bound (1/4^k)')

plt.yscale('log')
plt.title("Error Probability vs. Number of Iterations (k)")
plt.xlabel("Number of Iterations (k)")
plt.ylabel("Probability of Error (Log Scale)")
plt.xticks(list(k_values))
plt.grid(True, which="both", ls="-", alpha=0.2)
plt.legend()

print("Experiment complete. Saving plot...")
path1 = save_plot("miller_rabin_error_vs_k.png")
print(f"Saved: {path1}")
plt.show()


# -----------------------------
# Experiment 3
# Fermat vs Miller-Rabin on composites
# -----------------------------
k_values = [1, 2, 3, 5, 10]
num_composites = 10000

carmichaels = [
    561, 1105, 1729, 2465, 2821, 6601, 8911,
    10585, 15841, 29341, 41041, 46657, 52633
]

composites = list(carmichaels)

while len(composites) < num_composites:
    candidate = random.randint(100, 50000)
    if candidate % 2 != 0 and not is_prime(candidate):
        if candidate not in composites:
            composites.append(candidate)

fermat_errors = []
mr_errors = []

for k in k_values:
    f_count = 0
    m_count = 0

    for n in composites:
        if is_fermat_prime(n, k):
            f_count += 1
        if miller_rabin(n, k):
            m_count += 1

    fermat_errors.append(f_count)
    mr_errors.append(m_count)
    print(f"Finished testing k={k} | Fermat Errors: {f_count} | MR Errors: {m_count}")

x = np.arange(len(k_values))
width = 0.35

fig, ax = plt.subplots(figsize=(10, 6))
rects1 = ax.bar(x - width / 2, fermat_errors, width, label='Fermat Test')
rects2 = ax.bar(x + width / 2, mr_errors, width, label='Miller-Rabin Test')

ax.set_xlabel('Number of Iterations (k)')
ax.set_ylabel('Number of Escaped Composites')
ax.set_title(f'Algorithm Reliability: Escaped Composites vs. k (Total n={num_composites})')
ax.set_xticks(x)
ax.set_xticklabels([f'k={k}' for k in k_values])
ax.legend()

def autolabel(rects):
    for rect in rects:
        height = rect.get_height()
        ax.annotate(
            f'{height}',
            xy=(rect.get_x() + rect.get_width() / 2, height),
            xytext=(0, 3),
            textcoords="offset points",
            ha='center',
            va='bottom'
        )

autolabel(rects1)
autolabel(rects2)

plt.tight_layout()
print("Saving comparison bar chart...")
path2 = save_plot("fermat_vs_miller_rabin_escaped_composites.png")
print(f"Saved: {path2}")
plt.show()